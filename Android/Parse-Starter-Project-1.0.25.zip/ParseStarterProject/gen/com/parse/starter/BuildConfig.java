/** Automatically generated file. DO NOT MODIFY */
package com.parse.starter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}