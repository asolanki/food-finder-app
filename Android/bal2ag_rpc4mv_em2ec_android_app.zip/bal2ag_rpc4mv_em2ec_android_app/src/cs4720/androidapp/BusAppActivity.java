package cs4720.androidapp;

import cs4720.androidapp.R;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;

//Code for TabHost setup adapted from the Android Developers site: http://developer.android.com/resources/tutorials/views/hello-tabwidget.html
public class BusAppActivity extends TabActivity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		try {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.main);

			Resources res = getResources(); // Resource object to get Drawables
			TabHost tabHost = getTabHost();  // The activity TabHost
			TabHost.TabSpec spec;  // Resusable TabSpec for each tab
			Intent intent;  // Reusable Intent for each tab

			// Create an Intent to launch an Activity for the tab (to be reused)
			intent = new Intent().setClass(this, NearestBusActivity.class);

			//All bus icons are courtesy:
			//http://code.google.com/p/android-bus-route-tracker-ss12/logo?cct=1298152927
			
			// Initialize a TabSpec for each tab and add it to the TabHost
			spec = tabHost.newTabSpec("nearest_stop").setIndicator("Nearest Stop",
					res.getDrawable(R.drawable.bus))
					.setContent(intent);
			tabHost.addTab(spec);

			// Do the same for the other tabs
			intent = new Intent().setClass(this, BusScheduleActivity.class);
			spec = tabHost.newTabSpec("bus_schedule").setIndicator("Bus Schedules",
					res.getDrawable(R.drawable.bus))
					.setContent(intent);
			tabHost.addTab(spec);

			intent = new Intent().setClass(this, StopInfoActivity.class);
			spec = tabHost.newTabSpec("stop_info").setIndicator("Incoming Buses",
					res.getDrawable(R.drawable.bus))
					.setContent(intent);
			tabHost.addTab(spec);

			intent = new Intent().setClass(this, StopListActivity.class);
			spec = tabHost.newTabSpec("stop_list").setIndicator("Stop List",
					res.getDrawable(R.drawable.bus))
					.setContent(intent);
			tabHost.addTab(spec);

			//Start on the stop list tab
			tabHost.setCurrentTab(3);
		} catch (Exception e) { e.printStackTrace(); }
	}
}