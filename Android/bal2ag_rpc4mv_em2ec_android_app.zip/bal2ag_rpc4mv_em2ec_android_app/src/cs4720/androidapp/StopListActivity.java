package cs4720.androidapp;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

//Simply displays the list of UTS stops and their stop numbers. Uses a simple webservice that
//returns this information from the bussystems database as an XML form.
public class StopListActivity extends Activity {

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		TextView display = new TextView(this);
		display.setTextSize((float)20.0);
		display.setTextColor(Color.parseColor("#FF8000"));
		display.setText("Stop ID/Name Listing\n");
		//Parser three returns an ArrayList of IndividualStops based on the XML returned by the webservice
		XML_Parser_Three p = new XML_Parser_Three();
		ArrayList<IndividualStop> val = p.parse();
		for (IndividualStop s : val)
		{
			//Display the stop number and name of each stop
			display.setText((String)display.getText() + "\n" + s.getNum() + ": " + s.getName());
		}

		ScrollView theView = new ScrollView(this);
		LinearLayout ll = new LinearLayout(this);
		ll.setOrientation(LinearLayout.VERTICAL);
		ll.addView(display);
		theView.addView(ll);
		setContentView(theView);

	}
}
