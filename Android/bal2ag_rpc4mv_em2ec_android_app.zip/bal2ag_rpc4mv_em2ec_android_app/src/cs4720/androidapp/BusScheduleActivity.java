package cs4720.androidapp;

import android.app.*;
import android.graphics.Color;
import android.os.*;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

//This activity contains six buttons, one for each supported UTS route. It will display the current schedule
//of a given bus route (every X minutes). Most of this code is pretty hideous and could use some serious
//refactoring, but it works.
public class BusScheduleActivity extends Activity {

	//XML parser for this web service
	private XML_Parser_Two p2 = new XML_Parser_Two();
	//Buttons for each route
	protected Button northlineButton;
	protected Button uloopButton;
	protected Button greenButton;
	protected Button cgsButton;
	protected Button csButton;
	protected Button shsButton;
	//TextView for displaying the output
	protected TextView display;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		//Horrible hack to get spacing between buttons :(
		TextView linebreak1 = new TextView(this);
		linebreak1.setTextSize((float)10);
		TextView linebreak2 = new TextView(this);
		linebreak2.setTextSize((float)10);
		TextView linebreak3 = new TextView(this);
		linebreak3.setTextSize((float)10);
		TextView linebreak4 = new TextView(this);
		linebreak4.setTextSize((float)10);
		TextView linebreak5 = new TextView(this);
		linebreak5.setTextSize((float)10);

		//Initialize all buttons
		northlineButton = new Button(this);
		northlineButton.setText("Current Schedule: Northline");
		northlineButton.setTextSize((float)18.0);
		northlineButton.setBackgroundColor(Color.parseColor("#FF8000"));
		uloopButton = new Button(this);
		uloopButton.setText("Current Schedule: U-Loop");
		uloopButton.setTextSize((float)18.0);
		uloopButton.setBackgroundColor(Color.parseColor("#FF8000"));
		greenButton = new Button(this);
		greenButton.setText("Current Schedule: Green");
		greenButton.setTextSize((float)18.0);
		greenButton.setBackgroundColor(Color.parseColor("#FF8000"));
		cgsButton = new Button(this);
		cgsButton.setText("Current Schedule: CGS");
		cgsButton.setTextSize((float)18.0);
		cgsButton.setBackgroundColor(Color.parseColor("#FF8000"));
		csButton = new Button(this);
		csButton.setText("Current Schedule: CS");
		csButton.setTextSize((float)18.0);
		csButton.setBackgroundColor(Color.parseColor("#FF8000"));
		shsButton = new Button(this);
		shsButton.setText("Current Schedule: SHS");
		shsButton.setTextSize((float)18.0);
		shsButton.setBackgroundColor(Color.parseColor("#FF8000"));

		//Configure the text format
		display = new TextView(this);
		display.setTextSize((float)25.0);
		display.setTextColor(Color.parseColor("#FF8000"));

		//Make it a scroll view showing a linear layout of the buttons and display
		ScrollView theView = new ScrollView(this);
		LinearLayout ll = new LinearLayout(this);
		ll.setOrientation(LinearLayout.VERTICAL);
		ll.addView(northlineButton);
		ll.addView(linebreak1);
		ll.addView(uloopButton);
		ll.addView(linebreak2);
		ll.addView(greenButton);
		ll.addView(linebreak3);
		ll.addView(cgsButton);
		ll.addView(linebreak4);
		ll.addView(csButton);
		ll.addView(linebreak5);
		ll.addView(shsButton);
		ll.addView(display);
		theView.addView(ll);
		setContentView(theView);

		//Listeners for each button
		northlineButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showTimeOne();
			}
		});    
		uloopButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showTimeTwo();
			}
		});
		greenButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showTimeThree();
			}
		});    
		cgsButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showTimeFour();
			}
		});
		csButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showTimeFive();
			}
		});    
		shsButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showTimeSix();
			}
		});
	}

	//Call the parser and show the appropriate output. This could all be put in one method,
	//but this works too.
	protected void showTimeOne() {
		display.setText("Loading current schedule...");
		int time = p2.parse("Northline");
		if (time > 0)
			display.setText("Northline is running every " +time+ " minutes.");
		else
			display.setText("Northline is not currently running.");
	}

	protected void showTimeTwo() {
		display.setText("Loading current schedule...");
		int time = p2.parse("ULoop");
		if (time > 0)
			display.setText("University Loop is running every " +time+ " minutes.");
		else
			display.setText("University Loop is not currently running.");
	}
	protected void showTimeThree() {
		display.setText("Loading current schedule...");
		int time = p2.parse("Green");
		if (time > 0)
			display.setText("Green Route is running every " +time+ " minutes.");
		else
			display.setText("Green Route is not currently running.");
	}

	protected void showTimeFour() {
		display.setText("Loading current schedule...");
		int time = p2.parse("CGS");
		if (time > 0)
			display.setText("Central Grounds Shuttle is running every " +time+ " minutes.");
		else
			display.setText("Central Grounds Shuttle is not currently running.");
	}
	protected void showTimeFive() {
		display.setText("Loading current schedule...");
		int time = p2.parse("CS");
		if (time > 0)
			display.setText("Colonnade Shuttle is running every " +time+ " minutes.");
		else
			display.setText("Colonnade Shuttle is not currently running.");
	}

	protected void showTimeSix() {
		display.setText("Loading current schedule...");
		int time = p2.parse("SHS");
		if (time > 0)
			display.setText("Stadium Hospital Shuttle is running every " +time+ " minutes.");
		else
			display.setText("Stadium Hospital Shuttle is not currently running.");
	}
}