package cs4720.androidapp;

import java.util.ArrayList;

//Used by the Stop Info and Stop List activities to represent individual stops. myArrivals is used only by
//Stop Info, and is filled based on incoming buses to a stop; it is empty for the Stop List activity.
public class IndividualStop {

	private String name;
	private int number;
	private ArrayList<RouteTimePair> myArrivals;

	public IndividualStop(String n, int num)
	{
		//Clean up the goofy ampersand, which is an artifact of HTML
		if (n.contains("&amp;")) n = n.replace("&amp;", "&");
		//Terrible but necessary hack to remove an anomalous and extraneous line break. Grumble grumble
		if (n.contains("University Heights/Ivy Road")) n = "University Heights/Ivy Road";
		name = n;
		number = num;
		myArrivals = new ArrayList<RouteTimePair>();
	}

	public String getName()
	{
		return name;
	}
	public int getNum()
	{
		return number;
	}
	public ArrayList<RouteTimePair> getArrivals()
	{
		return myArrivals;
	}

	public void addArrival(RouteTimePair r)
	{
		myArrivals.add(r);
	}

	//This is formatted for use by the Stop Info activity
	public String toString()
	{
		String val = name + "\n";
		for (RouteTimePair r : myArrivals)
		{
			val += "-" + r.toString() + "\n";
		}
		return val;
	}

}
