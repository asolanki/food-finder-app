package cs4720.androidapp;

import android.app.*;
import android.content.Context;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.*;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

//This activity identifies the nearest Bus Stop to a user's current location, and presents some information about
//it. It uses the first web service we created (a php file that queries the database and returns XML, which is parsed
//by XML_Parser_One).

//Location retrieval code adapted from http://www.javacodegeeks.com/2010/09/android-location-based-services.html
public class NearestBusActivity extends Activity {

	private cs4720.androidapp.Location myLoc;
	private XML_Parser_One p1 = new XML_Parser_One();
	private TextView display;
	private Button retrieveLocationButton;

	//Used for requesting location updates by GPS
	private static final long MINIMUM_DISTANCE_CHANGE_FOR_UPDATES = 1; // in Meters
	private static final long MINIMUM_TIME_BETWEEN_UPDATES = 1000; // in Milliseconds

	protected LocationManager locationManager;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		retrieveLocationButton = new Button(this);
		retrieveLocationButton.setText("Find Nearest Stop");
		retrieveLocationButton.setTextSize((float)18.0);
		retrieveLocationButton.setBackgroundColor(Color.parseColor("#FF8000"));

		display = new TextView(this);
		display.setTextSize((float)25.0);
		display.setTextColor(Color.parseColor("#FF8000"));

		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		//This has to be done to request location updates, but we don't want to do anything in these instances.
		//Alternatively we could display a popup message, or whatever.
		LocationListener locationListener = new LocationListener() {
			public void onLocationChanged(Location location) {

			}

			public void onStatusChanged(String s, int i, Bundle b) {

			}

			public void onProviderDisabled(String s) {

			}

			public void onProviderEnabled(String s) {

			}
		};

		//Listen for location changes.
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MINIMUM_TIME_BETWEEN_UPDATES, MINIMUM_DISTANCE_CHANGE_FOR_UPDATES, locationListener);

		retrieveLocationButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showCurrentLocation();
			}
		});

		//Set up the views/layout
		ScrollView theView = new ScrollView(this);
		LinearLayout ll = new LinearLayout(this);
		ll.setOrientation(LinearLayout.VERTICAL);
		ll.addView(retrieveLocationButton);
		ll.addView(display);
		theView.addView(ll);
		setContentView(theView);

	}

	//Called when a user attempts to find the nearest stop.
	protected void showCurrentLocation() {

		display.setText("Attempting to retrieve location from your device...");
		//Tries to get the last known location from the device
		Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		//Might fail to grab last known location, in which case a message should be displayed.
		if (location != null) {
			myLoc = p1.parse(location.getLatitude(), location.getLongitude());
			BusStop stop = myLoc.getNearestStop();

			display.setText(stop.toString());

		}
		else {
			display.setText("Unable to get a valid location from your device.");
		}

	}


}