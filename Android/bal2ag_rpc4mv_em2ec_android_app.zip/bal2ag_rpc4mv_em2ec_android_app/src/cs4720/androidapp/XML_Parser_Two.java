package cs4720.androidapp;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XML_Parser_Two {

	/* Code to parse XML adapted from the following website:
	 * http://www.mkyong.com/java/how-to-read-xml-file-in-java-dom-parser/
	 */
	//This parser is used by BusScheduleActivity. It calls our heroku webservice
	//to get the current running schedule for a particular bus. This "calculation"
	//is done server-side (though it's really just a big "switch" statement, basically).
	//The XML here is very simple; as usual, see the form itself to understand how it's
	//parsed.
	public int parse(String req) {
		String uri = "http://webserviceror.heroku.com/?route="+req;
		try
		{
			URL url = new URL(uri);
			HttpURLConnection connection =
				(HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Accept", "application/xml");


			InputStream xml = connection.getInputStream();

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(xml);

			NodeList nList = doc.getElementsByTagName("UTSRouteFreqency");

			Node theNode = nList.item(0);
			Element eh = (Element) theNode;

			int service = Integer.parseInt(getTagValue("Current_Service", eh));

			return service;

		} catch (Exception e) { e.printStackTrace(); }
		return 0;
	}

	private static String getTagValue(String sTag, Element eElement) {
		NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();

		Node nValue = (Node) nlList.item(0);

		return nValue.getNodeValue();
	}
}
