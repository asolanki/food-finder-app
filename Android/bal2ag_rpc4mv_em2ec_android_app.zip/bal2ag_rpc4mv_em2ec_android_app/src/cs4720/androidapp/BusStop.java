package cs4720.androidapp;

//Used by the Nearest Stop service to represent a bus stop and its distance from an arbitrary location
//(determined upon initialization)
public class BusStop {

	private double myLat;
	private double myLong;
	private String stop;
	private String routes;
	private int dist_in_feet;

	public BusStop()
	{
		myLat = 0.0;
		myLong = 0.0;
		stop = "";
		routes = "";
		dist_in_feet = 0;
	}

	public BusStop(double la, double lo, String cs, String r, int d)
	{
		myLat = la;
		myLong = lo;
		stop = cs;
		routes = r;
		dist_in_feet = d;
	}

	public double getLat() {
		return myLat;
	}

	public double getLong() {
		return myLong;
	}

	public String getStop() {
		return stop;
	}

	public String getRoutes() {
		return routes;
	}

	public int getDist() {
		return dist_in_feet;
	}

	public String toString()
	{
		return "Stop Name: " + stop + "\nRoutes Serviced: " + routes + "\nDistance to stop (ft): " + dist_in_feet;
	}
}
