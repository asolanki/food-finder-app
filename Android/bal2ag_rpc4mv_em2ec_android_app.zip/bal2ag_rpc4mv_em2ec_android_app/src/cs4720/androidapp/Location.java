package cs4720.androidapp;

//Used by the Nearest Stop activity to represent a user's location. Basically just used to
//identify the nearest stop.
public class Location {

	private double myLat;
	private double myLong;

	private BusStop nearestStop;

	public Location()
	{
		myLat = 0.0;
		myLong = 0.0;
	}

	public Location(double la, double lo)
	{
		myLat = la;
		myLong = lo;
	}

	public void setNearestStop(BusStop s)
	{
		nearestStop = s;
	}

	public double getLat ()
	{
		return myLat;
	}

	public double getLong ()
	{
		return myLong;
	}

	public BusStop getNearestStop()
	{
		return nearestStop;
	}
}
