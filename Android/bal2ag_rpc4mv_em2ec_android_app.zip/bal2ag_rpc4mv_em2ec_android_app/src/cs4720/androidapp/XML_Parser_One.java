package cs4720.androidapp;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XML_Parser_One {

	/* Code to parse XML adapted from the following website:
	 * http://www.mkyong.com/java/how-to-read-xml-file-in-java-dom-parser/
	 */
	//This parser is used by NearestBusActivity. It grabs the nearest stop to the user (calculated
	//server-side and returned as XML). The XML parsing is simple, just look at the format of the XML
	//document to see why it works.
	public Location parse(double lat, double longi) {
		Location myLoc = new Location(lat, longi);
		String latitude = lat + "";
		String longitude = longi + "";
		String uri = "http://plato.cs.virginia.edu/~bal2ag/project_phase1/nearest_stop.php?lat="+latitude+"&long="+longitude;
		try
		{
			URL url = new URL(uri);
			HttpURLConnection connection =
				(HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Accept", "application/xml");


			InputStream xml = connection.getInputStream();

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(xml);

			NodeList nList = doc.getElementsByTagName("bus_info");
			NodeList busLoc = doc.getElementsByTagName("bus_location");

			Node theNode = nList.item(0);
			Node busLocNode = busLoc.item(0);

			Element eh = (Element) theNode;
			Element el = (Element) busLocNode;

			String theStop = getTagValue("stop", eh);
			String theRoutes = getTagValue("routes", eh);
			int theDist = Integer.parseInt(getTagValue("distance_in_feet", eh));
			double theLat = Double.parseDouble(getTagValue("latitude", el));
			double theLong = Double.parseDouble(getTagValue("longitude", el));

			BusStop theBusStop = new BusStop (theLat, theLong, theStop, theRoutes, theDist);

			myLoc.setNearestStop(theBusStop);

		} catch (Exception e) { e.printStackTrace(); }
		return myLoc;
	}

	private static String getTagValue(String sTag, Element eElement) {
		NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();

		Node nValue = (Node) nlList.item(0);

		return nValue.getNodeValue();
	}
}
