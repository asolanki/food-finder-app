package cs4720.androidapp;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/* Code to parse XML adapted from the following website:
 * http://www.mkyong.com/java/how-to-read-xml-file-in-java-dom-parser/
 */
//This parser is used by StopListActivity. It makes a GET request to
//a simple webservice we wrote which returns a list of all UTS stop numbers
//and names (from the bussystems database) as XML. Again, see the XML form
//to understand the parsing algorithm.
public class XML_Parser_Three {

	public ArrayList<IndividualStop> parse() {
		String uri = "http://plato.cs.virginia.edu/~bal2ag/bus_stops.php";
		ArrayList<IndividualStop> final_val = new ArrayList<IndividualStop>();
		try
		{
			URL url = new URL(uri);
			HttpURLConnection connection =
				(HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Accept", "application/xml");

			InputStream xml = connection.getInputStream();

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(xml);

			NodeList nList = doc.getElementsByTagName("bus_stop");

			for (int i = 0; i < nList.getLength() - 1; i++)
			{
				Node theNode = nList.item(i);
				Element eh = (Element) theNode;
				int id = Integer.parseInt(getTagValue("id", eh));
				String loc = getTagValue("location", eh);
				final_val.add(new IndividualStop(loc, id));
			}

		} catch (Exception e) { e.printStackTrace(); }
		return final_val;
	}

	private static String getTagValue(String sTag, Element eElement) {
		NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();

		Node nValue = (Node) nlList.item(0);

		return nValue.getNodeValue();
	}
}
