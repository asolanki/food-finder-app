package cs4720.androidapp;

import android.app.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.*;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.*;

//This activity displays all incoming buses to a given stop (identified by its number)
//and their ETA in the next 30 mins. It uses the following webservice:
//http://avlweb.charlottesville.org/RTT/Public/RoutePositionET.aspx?PlatformNo=#
public class StopInfoActivity extends Activity {

	protected EditText stop_field;
	protected Button submit_button;
	protected TextView display;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		//GUI stuff
		stop_field = new EditText(this);
		stop_field.setHint("Enter stop number...");
		stop_field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		submit_button = new Button(this);
		submit_button.setText("See incoming buses");
		submit_button.setTextSize((float)18.0);
		submit_button.setBackgroundColor(Color.parseColor("#FF8000"));
		display = new TextView(this);
		display.setTextSize((float)25.0);
		display.setTextColor(Color.parseColor("#FF8000"));


		//grab_stop calls the webservice and parses the html
		submit_button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				try {
					IndividualStop stopka = grab_stop(Integer.parseInt(stop_field.getText().toString()));
					if (stopka.getArrivals().isEmpty())
						display.setText(stopka.toString() + "No incoming buses in the next 30 minutes :-(");
					else
						display.setText(stopka.toString());
				}
				catch (Exception e)
				{
					display.setText("Error getting stop info.");
				}
			}
		});

		//Initialize the gui
		ScrollView theView = new ScrollView(this);
		LinearLayout ll = new LinearLayout(this);
		ll.setOrientation(LinearLayout.VERTICAL);
		ll.addView(stop_field);
		ll.addView(submit_button);
		ll.addView(display);
		theView.addView(ll);
		setContentView(theView);

	}

	//This code is adapted from http://www.javaprogrammingforums.com/java-networking-tutorials/185-how-grab-html-source-website-url.html
	public IndividualStop grab_stop(int stop_num) throws Exception{

		//Set URL
		URL url = new URL("http://avlweb.charlottesville.org/RTT/Public/RoutePositionET.aspx?PlatformNo="+stop_num);
		URLConnection spoof = url.openConnection();

		//Spoof the connection so we look like a web browser
		spoof.setRequestProperty( "User-Agent", "Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 5.0; H010818)" );
		BufferedReader in = new BufferedReader(new InputStreamReader(spoof.getInputStream()));
		String strLine = "";

		IndividualStop is;

		int counter = 1;
		//Loop through the html source code
		while ((strLine = in.readLine()) != null){

			//Stop when we get to the line that auto-generates the HTML table
			if (counter == 12)
			{
				//To understand why all this works, you need to look at the format of the actual HTML line.
				String theStop;
				//Splits this line based on the <td> tag
				String [] arr = strLine.split("<td>");
				//Splits the second string of arr based on <th> tag
				String [] loc = arr[1].split("<th>");
				//Grab the location - loc[1] broken by "<", using the first element
				String [] the_stop = loc[1].split("<");
				theStop = the_stop[0];
				is = new IndividualStop(theStop, stop_num);
				boolean flag = false;
				String incomingRoute = "";
				String arrivalTime = "";
				//Start at arr[2]. Three lines for each entry - second is route name, third is arrival time
				for (int i = 2; i <= arr.length; i++)
				{
					if (i > 2) flag = true;
					int realval = (i - 2) % 3;
					if (realval == 1)
					{
						String [] temp = arr[i].split("<");
						incomingRoute = temp[0];
					}
					else if (realval == 2)
					{
						String [] temp = arr[i].split("<");
						arrivalTime = temp[0];
					}
					else if (flag)
					{
						is.addArrival(new RouteTimePair(incomingRoute, Integer.parseInt(arrivalTime)));
					}
				}
				return is;
			}
			counter++;
		}
		return null;
	}

}