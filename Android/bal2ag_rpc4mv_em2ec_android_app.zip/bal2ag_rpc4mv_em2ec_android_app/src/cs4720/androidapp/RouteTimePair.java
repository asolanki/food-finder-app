package cs4720.androidapp;

//Used by the Stop Info activity to display an incoming route to a stop.
//There are much better ways to do this, but it works.
public class RouteTimePair {

	private String routeName;
	private int arrivalTime;

	public RouteTimePair(String n, int a)
	{
		routeName = n;
		arrivalTime = a;
	}

	public String getName()
	{
		return routeName;
	}

	public int getArrivalTime()
	{
		return arrivalTime;
	}

	public String toString()
	{
		return routeName + " arriving in " + arrivalTime + " minute(s).";
	}
}
